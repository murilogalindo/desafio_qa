package com.americanas.pages;

public class Test1Page {
}

package com.americanas.pages;

public class Test3Page {
}

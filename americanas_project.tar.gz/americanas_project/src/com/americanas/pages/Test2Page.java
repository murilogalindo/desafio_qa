package com.americanas.pages;

public class Test2Page {
}

package com.americanas.base;

import org.openqa.selenium.WebDriver;

public class BasePage {

   WebDriver driver;

    public BasePage(WebDriver driver){

        this.driver = driver;
    }
    public void fecharNagegador(){

        getDriver().close();
    }

    public WebDriver getDriver() {
        return driver;
    }
}

package com.americanas.base;



public class Paramiters {

    public static final String URL = "https://www.americanas.com.br/";
    public static final String URL_FORM = "https://cliente.americanas.com.br/simple-login/cadastro/pf?next=https%3A%2F%2Fwww.americanas.com.br%2F#email";
}

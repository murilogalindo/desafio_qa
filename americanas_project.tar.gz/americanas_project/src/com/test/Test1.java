package com.test;

import com.americanas.base.Paramiters;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.awt.*;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Test1 {

    public static void main(String[] args) throws AWTException, InterruptedException {
        // write your code here

        System.out.println("Hello World");
        System.setProperty("webdriver.chrome.driver", "/home/murilo/Documentos/webdrivers/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.navigate().to(Paramiters.URL);

        //STEP 1
        //This code is commented out because it is not working properly
        //The selenium only clicks on tooltip to create  new client when it wants :D
        /*
        WebElement cadastre_se
                = driver.findElement(By.className("usr-act-text"));
        cadastre_se.click();

        Actions actions = new Actions(driver);
        WebElement cliente_novo
                = driver.findElement(By.xpath("//*[@id=\"h_user\"]/span[2]/div/a[2]"));
        cliente_novo.click();
        actions.moveToElement(cliente_novo).perform();

        driver.close();
        */
        driver.navigate().to(Paramiters.URL_FORM);
        String newWindow = driver.getWindowHandle();
        driver.switchTo().window(newWindow);

        //access form to register user
        //insert email
        WebElement email = (new WebDriverWait(driver, 5))
                .until(ExpectedConditions.presenceOfElementLocated(By.id("email-input")));
        email.sendKeys("test@hotmail.com");


        //insert password
        WebElement password
                = driver.findElement(By.id("password-input"));
        password.sendKeys("12");

        //insert CPF
        WebElement cpf
                = driver.findElement(By.id("cpf-input"));
        cpf.sendKeys("074.560.144-99");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("javascript:window.scrollBy(250,500)");
        //click to submit information
        WebElement submit
                = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/button"));
        submit.click();

        String check_email = driver.findElement(By.className("inputGroup-error ")).getText();
        Assert.assertEquals("E-mail já cadastrado", check_email);
        String check_password = driver.findElement(By.className("passwordWrapper-msg")).getText();
        Assert.assertEquals("fraca", check_password);


        //STEP 2
        //insert data on form
        //insert email
        WebElement email_valid = (new WebDriverWait(driver, 5))
                .until(ExpectedConditions.presenceOfElementLocated(By.id("email-input")));
        email_valid.sendKeys("test_test@hotmail.com");


        //insert password
        WebElement password_valid
                = driver.findElement(By.id("password-input"));
        password_valid.sendKeys("123456");


        //insert CPF
        WebElement cpf_valid
                = driver.findElement(By.id("cpf-input"));
        cpf_valid.sendKeys("074.560.144-99");


        //insert name
        WebElement name
                = driver.findElement(By.id("name-input"));
        name.sendKeys("murilo teste");

        //insert
        WebElement birthday
                = driver.findElement(By.id("birthday-input"));
        birthday.sendKeys("05/03/1987");

        //insert gender
        WebElement gender
                = driver.findElement(By.xpath("//*[@id=\"gender\"]/div[1]/label"));
        gender.click();

        //insert phone
        WebElement phone
                = driver.findElement(By.id("phone-input"));
        phone.sendKeys("81997731095");

        //click to submit information
        WebElement submit_register
                = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/form/button"));
        submit_register.click();


        //search by MotoG6 - 1
        WebElement motog
                = driver.findElement(By.id("h_search-input"));
        motog.sendKeys("Moto G6");

        //click to search
        WebElement click_search
                = driver.findElement(By.id("h_search-btn"));
        click_search.click();

        //click on phone 01
        WebElement motog_01
                = driver.findElement(By.className("ImageUI-bwhjk3-12 jApvYX PictureUI-sc-9rtsvr-1 fFDQOD"));
        motog_01.click();
            //buy botoG6 1
            WebElement by_motog_01
                    = driver.findElement(By.id("btn-buy"));
            by_motog_01.click();
            //my basket
            WebElement basket
                    = driver.findElement(By.id("btn-continue"));
            basket.click();

        //search by MotoG6 - 2
        WebElement motog2
                = driver.findElement(By.id("h_search-input"));
        motog2.sendKeys("Moto G6");

        //click to search
        WebElement click_search2
                = driver.findElement(By.id("h_search-btn"));
        click_search2.click();

            //click on phone 02
            WebElement motog_02
                    = driver.findElement(By.xpath("//*[@id=\"content-middle\"]/div[6]/div/div/div/div[1]/div[3]/div/div[2]/a/section/div[2]/div[1]/h2"));
            motog_02.click();
            //buy botoG6 1
            WebElement by_motog_02
                    = driver.findElement(By.id("btn-buy"));
            by_motog_02.click();
            //my basket
            WebElement basket2
                    = driver.findElement(By.id("btn-continue"));
            basket2.click();

            String validate_total_value = driver.findElement(By.className("summary-total")).getText();
            Assert.assertEquals("2.375,38", validate_total_value);

        String total_12x = driver.findElement(By.className("summary-totalInstallments")).getText();
        Assert.assertEquals("em até 12x sem juros", total_12x);

    }

}

